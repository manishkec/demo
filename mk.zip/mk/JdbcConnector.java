package test.mk;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcConnector {
	static String url = "jdbc:mysql://localhost:3306/demo";
	static String user ="root";
	static String pass = "rootpassword";
	protected static Connection getMySqlConnectionObject() throws SQLException {
		return DriverManager.getConnection(url, user, pass);
	}
	
	protected static Statement getStatementObject(Connection conn) throws SQLException {
		return conn.createStatement();
	}
}
