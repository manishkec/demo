package test.mk;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

//Deletes a Department table
public class JdbcDemo3 {
	public static void main(String[] args) {
		try {
			Connection con = JdbcConnector.getMySqlConnectionObject();
			Statement st = con.createStatement();
			String sql = "Drop TABLE DEPARTMENT ";

			int result = st.executeUpdate(sql);

			System.out.print(result == 0 ? "Table is deleted": "Table is not deleted ");

		} catch (SQLException e) {
			System.out.println("Table is not deleted.");
			System.out.println("Reason : " + e.getMessage());
		}
	}
}
