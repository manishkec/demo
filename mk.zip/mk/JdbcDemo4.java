package test.mk;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class JdbcDemo4 {
	public static void main(String[] args) {
		try {
			Connection con = JdbcConnector.getMySqlConnectionObject();
			// Create SQL statement
		      String SQL = "INSERT INTO Student(id,firstname,lastname,department) " +
		                   "VALUES(?, ?, ?, ?)";

		      // Create preparedStatement
		      PreparedStatement stmt = con.prepareStatement(SQL);

		      // Set auto-commit to false
		      con.setAutoCommit(false);
		  
		      // Set the variables
		      stmt.setInt( 1, 103 );
		      stmt.setString( 2, "Rahul" );
		      stmt.setString( 3, "Dash" );
		      stmt.setString( 4, "CSE" );
		      // Add it to the batch
		      stmt.addBatch();

		      // Set the variables
		      stmt.setInt( 1, 104 );
		      stmt.setString( 2, "Ajay" );
		      stmt.setString( 3, "Pratap" );
		      stmt.setString( 4, "ECE" );
		      // Add it to the batch
		      stmt.addBatch();

		      stmt.executeBatch();

		      //Explicitly commit statements to apply changes
		      con.commit();

		      // Clean-up environment
		      stmt.close();
		      con.close();
		} catch (SQLException e) {
			System.out.println("Something went wrong ");
			e.getMessage();
		}
		}
}
