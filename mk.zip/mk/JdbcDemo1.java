package test.mk;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcDemo1 {
	static String url = "jdbc:mysql://localhost:3306/demo";
	static String user ="root";
	static String pass = "rootpassword";
	
	public static void main(String[] args) {
		try {
			Connection myCon = DriverManager.getConnection(url, user, pass);
			
			Statement st = myCon.createStatement();
			
			String sql = "select * from student";
			
			ResultSet result = st.executeQuery(sql);
			int i = 1;
			while(result.next()) {
				System.out.print(i+": ");
				System.out.println(result.getString("firstname") + " " + result.getString("lastname"));
				i++;
			}
		}catch (SQLException e) {
			System.out.println("Something went wrong");
		}
	}
}
