package test.mk;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

//Creates Department Table
public class JdbcDemo2 {

	public static void main(String[] args) throws SQLException {
		try {
			Connection con = JdbcConnector.getMySqlConnectionObject();
			Statement st = con.createStatement();
			String sql = "CREATE TABLE DEPARTMENT " + "(id INTEGER, " + " DeptName VARCHAR(255), "
					+ " StudentCount INTEGER) ";

			int result = st.executeUpdate(sql);

			System.out.print(result == 0 ? "Table is created": "Table is not created ");

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}

}
